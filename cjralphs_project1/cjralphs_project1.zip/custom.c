// Caleb Ralphs
#include "custom.h"   

void main(void) {
    handleFile("custom.txt");
}