// Caleb Ralphs

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>


void handleCommand(int process, char* cmd, char* env[]) {
    if process == 0 {
        execvp(cmd, env);
    }
    else {
        wait(NULL);
    }
}


void printStatistics(struct timeval clock_init,
                     struct timeval clock_end, 
                     long pageFault_init,
                     long pageFault_end,
                     long pageFaultReclaimed_init,
                     long pageFaultReclaimed_end) {
    
    long pageFaults, pageFaultsReclaimed;
    float elapsed_time;

    pageFaults = pageFault_end - pageFault_init;
    pageFaultsReclaimed = pageFaultReclaimed_end - pageFaultReclaimed_init;
    // time in milliseconds
    elapsed_time = ((float) clock_end.tv_usec - (float) clock_init.tv_usec)/1000 + ((float) clock_end.tv_sec - (float) clock_init.tv_sec)*1000 

    printf("\n-- Statistics ---");
    printf("Elapsed Time: %.2f milliseconds", elapsed_time);
    printf("Page Faults: %1d", pageFaults);
    printf("Page Faults (reclaimed): %1d", pageFaultsReclaimed);
    printf("-- End of Statistics --\n");
}


void whoamiCommand(void) {
    printf("Running command: whoami");
    
    struct timeval clock_init;
    struct timeval clock_end;
    struct rusage rusage_info;
    long pageFault_init, pageFault_end, pageFaultReclaimed_init, pageFaultReclaimed_end;

    getrusage(RUSAGE_CHILDREN, &rusage_info);
    pageFault_init = rusage_info.majflt;
    pageFaultReclaimed_init = rusage_info.minflt;
    getimeofday(&clock_init, NULL);
    
    int process = fork();
    char* cmd = "whoami";
    char* env[] = {"whoami", NULL};
    handleCommand(process, cmd, env);

    getimeofday(&clock_end, NULL);
    getrusage(RUSAGE_CHILDREN, &rusage_info);
    pageFault_end = rusage_info.majflt;
    pageFaultReclaimed_end = rusage_info.minflt;

    printStatistics(clock_init, clock_end, pageFault_init, pageFault_end, pageFaultReclaimed_init, pageFaultReclaimed_end);
}

void main(NULL) {
    whoamiCommand();
}